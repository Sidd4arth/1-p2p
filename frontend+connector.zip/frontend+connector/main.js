const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");

// ===== LOAD BACKEND SAFELY =====
let backend = null;
let sendMessage = null;
let chatHistory = null;

try {
  backend = require("./backend/index"); // starts discovery + TCP server
  sendMessage = require("./backend/message_sender");
  chatHistory = require("./backend/chat_history");
  console.log("Backend loaded successfully.");
} catch (err) {
  console.error("Backend failed to start:", err);
}

let mainWindow;

// ===== CREATE WINDOW =====
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 600,
    minWidth: 800,
    minHeight: 500,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  mainWindow.loadFile("index.html");
}

// ===== APP READY =====
app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// ===== APP CLOSE =====
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// ============================================================
//                     IPC HANDLERS
// ============================================================

// GET ALL PEERS
ipcMain.handle("get-peers", () => {
  try {
    return require("./backend/peers.json");
  } catch (err) {
    console.error("Error reading peers.json:", err);
    return {};
  }
});

// GET MY INFO
ipcMain.handle("get-my-info", () => {
  try {
    return require("./backend/my_info.json");
  } catch (err) {
    console.error("Error reading my_info.json:", err);
    return {};
  }
});

// SEND MESSAGE
ipcMain.handle("send-message", async (event, { toList, text }) => {
  try {
    const myInfo = require("./backend/my_info.json");
    return await sendMessage(myInfo, toList, text);
  } catch (err) {
    console.error("Send message failed:", err);
    return { error: true };
  }
});

// GET CHAT HISTORY
ipcMain.handle("get-chat-history", (event, peerId) => {
  try {
    return chatHistory.getHistory(peerId);
  } catch (err) {
    console.error("Chat history failed:", err);
    return [];
  }
});

// ============================================================
//  BACKEND → FRONTEND REAL-TIME MESSAGE FORWARDING
// ============================================================
if (backend && backend.serverEventEmitter) {
  backend.serverEventEmitter.on("chat-message", (msg) => {
    if (mainWindow) {
      mainWindow.webContents.send("new-message", msg);
    }
  });
} else {
  console.log("Warning: backend event emitter missing");
}
