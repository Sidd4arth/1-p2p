console.log("Renderer loaded");

// Test API immediately when the page loads
window.addEventListener("DOMContentLoaded", async () => {

    console.log("=== CampusComm Renderer ===");

    // 1. Load my info
    const me = await window.CampusAPI.getMyInfo();
    console.log("My Info:", me);

    // 2. Load all peers
    const peers = await window.CampusAPI.getPeers();
    console.log("Peers:", peers);

    // 3. Listen for new chat messages
    window.CampusAPI.onNewMessage((msg) => {
        console.log("📩 New chat message received:", msg);
        // Later we update UI here
    });
});
