// preload.js
console.log("Preload script loaded");

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("CampusAPI", {

  // Get all peers
  getPeers: () => ipcRenderer.invoke("get-peers"),

  // Get my own info
  getMyInfo: () => ipcRenderer.invoke("get-my-info"),

  // Send chat message
  sendMessage: (toList, text) =>
    ipcRenderer.invoke("send-message", { toList, text }),

  // Get chat history for a peer
  getChatHistory: (peerId) =>
    ipcRenderer.invoke("get-chat-history", peerId),

  // Listen to real-time incoming chat messages
  onNewMessage: (callback) =>
    ipcRenderer.on("new-message", (event, msg) => callback(msg))
});
