// client_test.js
const TCPClient = require('./tcp_client');

const peerIp = process.env.IP || "127.0.0.1";
const peerPort = process.env.PORT ? Number(process.env.PORT) : 5000;

const msg = {
    type: "chat",
    text: "Hello from client_test!",
    time: new Date().toISOString()
};

TCPClient.send(peerIp, peerPort, msg)
    .then(reply => {
        console.log("[client_test] Server replied:", reply);
    })
    .catch(err => {
        console.error("[client_test] Error:", err.message);
    });
