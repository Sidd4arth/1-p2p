// cli_discovery_test.js
// Quick test CLI for discovery
const Discovery = require('./discovery');
const { v4: uuidv4 } = require('uuid');

const MY_ID = process.env.ID || uuidv4();
const MY_NAME = process.env.NAME || `Peer-${MY_ID.slice(0,6)}`;
const MY_PORT = process.env.PORT ? Number(process.env.PORT) : 5000;

// instantiate
const discovery = new Discovery({ id: MY_ID, name: MY_NAME, port: MY_PORT });

// start
discovery.start();

console.log(`Started discovery as ${MY_NAME} (id:${MY_ID}) - UDP port ${process.env.UDP_PORT || 41234}`);
console.log('Commands: "peers" to list, "stop" to exit\n');

const readline = require('readline').createInterface({ input: process.stdin, output: process.stdout });
readline.on('line', (line) => {
  const cmd = line.trim();
  if (cmd === 'peers') {
    const peers = discovery.getPeers();
    console.log('Known peers:');
    for (const id in peers) {
      const p = peers[id];
      console.log(`${id} - ${p.name} - ${p.ip}:${p.port} - lastSeen: ${p.lastSeen}`);
    }
  } else if (cmd === 'stop' || cmd === 'exit' || cmd === 'quit') {
    discovery.stop();
    process.exit(0);
  } else {
    console.log('Unknown command. Use "peers" or "stop".');
  }
});
