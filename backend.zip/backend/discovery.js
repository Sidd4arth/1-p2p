// discovery.js
const dgram = require('dgram');
const fs = require('fs');
const path = require('path');

const UDP_PORT = process.env.UDP_PORT ? Number(process.env.UDP_PORT) : 41234;
const BROADCAST_ADDR = '192.168.1.255';
const ANNOUNCE_INTERVAL_MS = 3000;
const PEERS_FILE = path.join(__dirname, 'peers.json');

class Discovery {
  constructor(myInfo) {
    if (!myInfo || !myInfo.id || !myInfo.port) throw new Error('myInfo must include id and port');
    this.myInfo = myInfo;
    this.sock = dgram.createSocket('udp4');
    this.knownPeers = this._loadPeers();
    this._interval = null;
    this._listening = false;

    // Bind and listen
    this.sock.on('message', (msg, rinfo) => this._onMessage(msg, rinfo));
    this.sock.on('error', (err) => console.error('[discovery] UDP socket error:', err.message));
  }

  _loadPeers() {
    try {
      if (fs.existsSync(PEERS_FILE)) {
        const raw = fs.readFileSync(PEERS_FILE, 'utf8');
        return JSON.parse(raw || '{}');
      }
    } catch (e) {
      console.error('[discovery] failed to load peers.json', e.message);
    }
    return {};
  }

  _savePeers() {
    try {
      fs.writeFileSync(PEERS_FILE, JSON.stringify(this.knownPeers, null, 2));
    } catch (e) {
      console.error('[discovery] failed to save peers.json', e.message);
    }
  }

  start() {
    this.sock.bind(UDP_PORT, () => {
      try { this.sock.setBroadcast(true); } catch(e) {}
      this._listening = true;
      console.log(`[discovery] listening on UDP ${UDP_PORT}`);
    });

    // periodic announce
    this._interval = setInterval(() => this._announce(), ANNOUNCE_INTERVAL_MS);
    // do one immediate announce
    this._announce();
  }

  stop() {
    if (this._interval) clearInterval(this._interval);
    try { this.sock.close(); } catch(e) {}
    this._listening = false;
    console.log('[discovery] stopped');
  }

  _announce() {
    const payload = {
      type: 'announce',
      id: this.myInfo.id,
      name: this.myInfo.name || null,
      port: this.myInfo.port,
      timestamp: new Date().toISOString()
    };
    const buf = Buffer.from(JSON.stringify(payload));
    this.sock.send(buf, 0, buf.length, UDP_PORT, BROADCAST_ADDR, (err) => {
      if (err) console.error('[discovery] announce send error:', err.message);
    });
  }

  _onMessage(msgBuf, rinfo) {
    let data = null;
    try { data = JSON.parse(msgBuf.toString()); } catch (e) { return; }
    if (!data || data.type !== 'announce' || data.id === this.myInfo.id) return;

    const peer = {
  id: data.id,
  name: data.name || `peer-${data.id.slice(0,6)}`,
  ip: rinfo.address,
  port: data.port,
  lastSeen: new Date().toISOString(),
  status: "online"
};


    const prev = this.knownPeers[peer.id];
    const changed = !prev || prev.ip !== peer.ip || prev.port !== peer.port || prev.name !== peer.name;
    this.knownPeers[peer.id] = peer;
    if (changed) {
      console.log(`[discovery] discovered/updated peer ${peer.name} ${peer.ip}:${peer.port} (id:${peer.id})`);
      this._savePeers();
      // emit an event maybe later; for now we just console.log
    } else {
      // Just update timestamp
      // save periodically - keep it simple and save on each update
      this.knownPeers[peer.id].lastSeen = peer.lastSeen;
      this.knownPeers[peer.id].status = "online";
      this._savePeers();

    }
  }

  getPeers() {
    return this.knownPeers;
  }
}

module.exports = Discovery;
