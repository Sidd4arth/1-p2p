// tcp_server.js
const net = require('net');
const EventEmitter = require('events');
const handshake = require('./handshake');
const fs = require('fs');
const path = require('path');

const VERIFIED_FILE = path.join(__dirname, "verified_peers.json");

class TCPServer extends EventEmitter {
    constructor(port, serverName = "Unknown") {
        super();
        this.port = port;
        this.serverName = serverName;
    }

    start() {
        this.server = net.createServer((socket) => {
            console.log(`[tcp_server] Connection from ${socket.remoteAddress}`);

            let stage = "await-hello";

            socket.on('data', (buffer) => {
                const msg = this._decode(buffer);
                if (!msg) return;

                if (stage === "await-hello" && msg.type === "hello") {
                    stage = "await-auth-response";
                    this._send(socket, handshake.createAuthRequest(this.serverName));
                    return;
                }

                if (stage === "await-auth-response" && msg.type === "auth-response") {
                    if (msg.token === handshake.AUTH_TOKEN) {
                            this._send(socket, handshake.createAuthOK());
                            stage = "authenticated";

                            // Mark peer online
                            this._savePeer(socket.remoteAddress);
                    }
                    else {
                        this._send(socket, handshake.createAuthFail());
                        socket.destroy();
                    }
                    return;
                }

                if (stage === "authenticated") {
                    this.emit("message", msg, socket);
                }
            });
        });

        this.server.listen(this.port, () => {
            console.log(`[tcp_server] Listening on TCP port ${this.port}`);
        });
    }

    _send(socket, json) {
        const body = Buffer.from(JSON.stringify(json));
        const header = Buffer.alloc(4);
        header.writeUInt32BE(body.length, 0);
        socket.write(Buffer.concat([header, body]));
    }

    _decode(buffer) {
        try {
            return JSON.parse(buffer.slice(4).toString());
        } catch {
            return null;
        }
    }

    _savePeer(ip) {
        let data = {};
        if (fs.existsSync(VERIFIED_FILE)) {
            data = JSON.parse(fs.readFileSync(VERIFIED_FILE, "utf8"));
        }

        data[ip] = {
            verified: true,
            lastSeen: new Date().toISOString(),
            status: "online"
        };

        fs.writeFileSync(VERIFIED_FILE, JSON.stringify(data, null, 2));
    }

}

module.exports = TCPServer;
