// chat_history.js
const fs = require("fs");
const path = require("path");

const HISTORY_FILE = path.join(__dirname, "chat_history.json");

function loadHistory() {
  if (!fs.existsSync(HISTORY_FILE)) return {};
  return JSON.parse(fs.readFileSync(HISTORY_FILE, "utf8"));
}

function saveHistory(history) {
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
}

function addMessage(peerId, message) {
  const history = loadHistory();

  if (!history[peerId]) history[peerId] = [];
  history[peerId].push(message);

  saveHistory(history);
}

function getHistory(peerId) {
  const history = loadHistory();
  return history[peerId] || [];
}

module.exports = { addMessage, getHistory };
