// index.js
const chatHistory = require("./chat_history");
const Discovery = require('./discovery');
const TCPServer = require('./tcp_server');
const statusManager = require("./status_manager");

const fs = require('fs');
const path = require('path');
const os = require('os');

// ===== FILE PATHS =====
const PEERS_FILE = path.join(__dirname, "peers.json");
const INFO_FILE = path.join(__dirname, "my_info.json");

const EventEmitter = require("events");
const serverEventEmitter = new EventEmitter();
module.exports.serverEventEmitter = serverEventEmitter;

// ===== LOAD PEERS =====
let peers = {};
if (fs.existsSync(PEERS_FILE)) {
    peers = JSON.parse(fs.readFileSync(PEERS_FILE, "utf8"));
}
function savePeers() {
    fs.writeFileSync(PEERS_FILE, JSON.stringify(peers, null, 2));
}

// ===== LOAD OR GENERATE IDENTITY =====
let savedInfo = {};
try {
    if (fs.existsSync(INFO_FILE)) {
        savedInfo = JSON.parse(fs.readFileSync(INFO_FILE, "utf8"));
    }
} catch (e) {
    console.log("[backend] Warning: Failed reading my_info.json", e.message);
}

// Generate missing values
const myInfo = {
    id: savedInfo.id || "peer-" + Math.random().toString(16).slice(2, 8),
    name: savedInfo.name || `Peer-${os.hostname().slice(0, 6)}`,
    port: savedInfo.port || Math.floor(4000 + Math.random() * 2000) // random safe range
};

// Save identity for future restarts
try {
    fs.writeFileSync(INFO_FILE, JSON.stringify({
        id: myInfo.id,
        name: myInfo.name,
        port: myInfo.port
    }, null, 2));
    console.log("[backend] Identity loaded:", myInfo);
} catch (e) {
    console.log("[backend] Warning: Failed writing identity:", e.message);
}

// ===== START DISCOVERY =====
const discovery = new Discovery(myInfo);
discovery.start();

// Merge discovery results every second
setInterval(() => {
    const discovered = discovery.getPeers();
    for (const id in discovered) {
        peers[id] = discovered[id];
    }
    savePeers();
}, 1000);

// ===== START TCP SERVER =====
const server = new TCPServer(myInfo.port, myInfo.name);
server.start();

server.on("message", (msg, socket) => {

    // STATUS UPDATE
    if (msg.type === "status-update") {
        const peer = peers[msg.id];
        if (!peer) {
            console.log("[status] Unknown peer:", msg.id);
            return;
        }

        peer.status = msg.status;
        peer.lastSeen = new Date().toISOString();
        savePeers();
        console.log(`[status] ${peer.name || msg.id} is now "${msg.status}"`);
        return;
    }

    // CHAT MESSAGE (modified block)
    // CHAT MESSAGE
if (msg.type === "chat") {

    console.log(`[chat] From ${msg.from}: "${msg.text}" @ ${msg.time}`);

    // ---- SAVE RECEIVED CHAT TO HISTORY ----
    try {
        chatHistory.addMessage(msg.from, {
            ...msg,
            status: "received"
        });
    } catch (e) {
        console.log("[chat-history] Failed to save message:", e.message);
    }

    // ---- EMIT EVENT FOR ELECTRON FRONTEND ----
    serverEventEmitter.emit("chat-message", {
        ...msg,
        status: "received"
    });

    return;
}


    // OTHER MESSAGE TYPES (if added later)
    console.log("[index] Received:", msg);
});

// ===== ONLINE / OFFLINE CHECK =====
setInterval(() => {
    const now = Date.now();

    for (const id in peers) {
        const last = new Date(peers[id].lastSeen).getTime();
        peers[id].status = (now - last > 10000) ? "offline" : "online";
    }

    savePeers();
}, 1000);

// ===== QUEUED MESSAGE DELIVERY =====
setInterval(async () => {
    const queueManager = require("./message_queue");
    const queue = queueManager.loadQueue();

    for (const peerId of Object.keys(queue)) {
        const peer = peers[peerId];
        if (!peer || peer.status !== "online") continue;

        const msgs = queue[peerId];
        for (const msg of msgs) {
            try {
                const TCPClient = require("./tcp_client");
                await TCPClient.send(peer.ip, peer.port, msg);
                console.log(`[queue] Delivered → ${peerId}: ${msg.text}`);
            } catch (err) {
                console.log(`[queue] Failed, retrying later`);
                break;
            }
        }

        queueManager.clearMessages(peerId);
    }
}, 5000);

// ===== BROADCAST STATUS =====
setInterval(() => {
    statusManager.broadcastStatus(myInfo);
}, 5000);

console.log("Backend running: Discovery + TCP server + Status manager");
