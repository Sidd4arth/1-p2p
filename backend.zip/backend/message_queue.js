// message_queue.js
const fs = require("fs");
const path = require("path");

const QUEUE_FILE = path.join(__dirname, "pending_messages.json");

function loadQueue() {
    if (!fs.existsSync(QUEUE_FILE)) return {};
    return JSON.parse(fs.readFileSync(QUEUE_FILE, "utf8"));
}

function saveQueue(queue) {
    fs.writeFileSync(QUEUE_FILE, JSON.stringify(queue, null, 2));
}

function addMessage(peerId, msg) {
    const queue = loadQueue();
    if (!queue[peerId]) queue[peerId] = [];
    queue[peerId].push(msg);
    saveQueue(queue);
}

function getMessages(peerId) {
    const queue = loadQueue();
    return queue[peerId] || [];
}

function clearMessages(peerId) {
    const queue = loadQueue();
    queue[peerId] = [];
    saveQueue(queue);
}

module.exports = {
    addMessage,
    getMessages,
    clearMessages,
    loadQueue,
    saveQueue
};
