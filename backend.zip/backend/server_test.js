// server_test.js
const TCPServer = require('./tcp_server');

const PORT = process.env.PORT ? Number(process.env.PORT) : 5000;

const server = new TCPServer(PORT);

server.on('message', (msg, socket) => {
    console.log('[server_test] Received message:', msg);

    // Echo back a reply (for debugging)
    const reply = Buffer.from(JSON.stringify({ type: "reply", ok: true }));
    const len = Buffer.alloc(4);
    len.writeUInt32BE(reply.length, 0);
    socket.write(Buffer.concat([len, reply]));
});

server.start();

console.log(`server_test running on port ${PORT}`);
console.log('Use "client_test" in Step 3 to test sending messages.');
