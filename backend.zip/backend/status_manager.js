// status_manager.js
const TCPClient = require("./tcp_client");
const fs = require("fs");
const path = require("path");

const PEERS_FILE = path.join(__dirname, "peers.json");

let myStatus = "online";

function setStatus(newStatus) {
    myStatus = newStatus;
    console.log(`[status] Your status is now: ${newStatus}`);
}

function getStatus() {
    return myStatus;
}

function broadcastStatus(myInfo) {
    const msg = {
        type: "status-update",
        id: myInfo.id,
        status: myStatus,
        timestamp: new Date().toISOString()
    };

    try {
        const peers = JSON.parse(fs.readFileSync(PEERS_FILE, "utf8"));
        for (const id in peers) {
            const p = peers[id];
            if (!p.ip || !p.port) continue;
            TCPClient.send(p.ip, p.port, msg);
        }
    } catch (err) {
        console.log("[status] Broadcast error:", err.message);
    }
}

module.exports = {
    setStatus,
    getStatus,
    broadcastStatus
};
