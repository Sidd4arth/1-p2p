// tcp_client.js
const net = require('net');
const handshake = require('./handshake');

class TCPClient {
    static send(peerIp, peerPort, jsonObj) {
        return new Promise((resolve, reject) => {
            const socket = new net.Socket();

            // Step 1: connect
            socket.connect(peerPort, peerIp, () => {
                // Send HELLO
                TCPClient._sendFramed(socket, handshake.createHello());
            });

            let authDone = false;

            socket.on('data', (data) => {
                const msg = TCPClient._decodeFramed(data);
                if (!msg) return;

                if (!authDone) {
                    if (msg.type === "auth-request") {
                        // Server is asking for token
                        TCPClient._sendFramed(socket, handshake.createAuthResponse());
                    } 
                    else if (msg.type === "auth-ok") {
                        authDone = true;
                        // After auth success → send actual message
                        TCPClient._sendFramed(socket, jsonObj);
                    }
                    else if (msg.type === "auth-fail") {
                        socket.destroy();
                        reject(new Error("Authentication failed"));
                    }
                    return;
                }

                // After auth, this is the reply from server
                resolve(msg);
                socket.destroy();
            });

            socket.on('error', (err) => reject(err));
        });
    }

    static _sendFramed(socket, jsonObj) {
        const body = Buffer.from(JSON.stringify(jsonObj));
        const header = Buffer.alloc(4);
        header.writeUInt32BE(body.length, 0);
        socket.write(Buffer.concat([header, body]));
    }

    static _decodeFramed(buf) {
        try {
            const json = JSON.parse(buf.slice(4).toString());
            return json;
        } catch {
            return null;
        }
    }
}

module.exports = TCPClient;
