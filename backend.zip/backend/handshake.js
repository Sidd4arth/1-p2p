// handshake.js

const AUTH_TOKEN = "lordoftheRings";

module.exports = {
    AUTH_TOKEN,

    createHello() {
        return { type: "hello" };
    },

    createAuthRequest(serverName) {
        return { type: "auth-request", name: serverName };
    },

    createAuthResponse() {
        return { type: "auth-response", token: AUTH_TOKEN };
    },

    createAuthOK() {
        return { type: "auth-ok" };
    },

    createAuthFail() {
        return { type: "auth-fail" };
    }
};
