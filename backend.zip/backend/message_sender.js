// message_sender.js
const TCPClient = require("./tcp_client");
const queue = require("./message_queue");
const fs = require("fs");
const path = require("path");
const chatHistory = require("./chat_history");   // <-- added

const PEERS_FILE = path.join(__dirname, "peers.json");

function loadPeers() {
    return JSON.parse(fs.readFileSync(PEERS_FILE, "utf8"));
}

async function sendMessage(myInfo, toList, text) {
    const peers = loadPeers();
    const time = new Date().toISOString();
    
    const msgObject = {
        type: "chat",
        from: myInfo.id,
        text,
        time
    };
    
    for (const peerId of toList) {
        const peer = peers[peerId];
        if (!peer) {
            console.log(`[msg] Unknown peer: ${peerId}`);
            continue;
        }

        msgObject.to = peerId;  // who this message instance is for

        if (peer.status === "online") {
            try {
                await TCPClient.send(peer.ip, peer.port, msgObject);
                console.log(`[msg] Sent to ${peerId}: "${text}"`);

                // SAVE HISTORY (status = sent)
                chatHistory.addMessage(peerId, { 
                    ...msgObject,
                    status: "sent" 
                });

            } catch (err) {
                console.log(`[msg] Failed to send to ${peerId}, queueing...`);
                queue.addMessage(peerId, msgObject);

                // SAVE HISTORY (status = queued)
                chatHistory.addMessage(peerId, { 
                    ...msgObject,
                    status: "queued" 
                });
            }
        } else {
            console.log(`[msg] ${peerId} offline → queued`);
            queue.addMessage(peerId, msgObject);

            // SAVE HISTORY (status = queued)
            chatHistory.addMessage(peerId, { 
                ...msgObject,
                status: "queued" 
            });
        }
    }
}

module.exports = sendMessage;
